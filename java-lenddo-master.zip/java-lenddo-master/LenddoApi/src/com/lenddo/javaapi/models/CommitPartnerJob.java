package com.lenddo.javaapi.models;

/**
 * Created by Joey Mar Antonio on 10/13/16.
 */
public class CommitPartnerJob {
    public boolean success;
}
